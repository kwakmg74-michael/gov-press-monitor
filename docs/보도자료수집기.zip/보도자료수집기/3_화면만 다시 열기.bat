﻿@echo off
chcp 65001 > nul
cd /d "%~dp0"
title 보도자료 모니터

python -m govpress dashboard --open
if errorlevel 1 (
  echo.
  echo  [!] 아직 모아 둔 자료가 없습니다.
  echo      "2_보도자료 모으기.bat" 을 먼저 실행하세요.
  echo.
  pause
)
exit /b 0
