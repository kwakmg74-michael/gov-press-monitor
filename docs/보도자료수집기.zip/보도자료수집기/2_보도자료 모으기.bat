﻿@echo off
chcp 65001 > nul
cd /d "%~dp0"
title 보도자료 수집기

echo.
echo  ===================================================
echo    보도자료를 모읍니다. 5분쯤 걸립니다.
echo    중간에 빨간 글씨가 나와도 괜찮습니다 -
echo    그 기관만 건너뛰고 나머지는 계속 모읍니다.
echo  ===================================================
echo.

where python >nul 2>nul
if errorlevel 1 goto NOPYTHON

echo  [1/4] 정부기관 (최근 7일)
python -m govpress collect --days 7

echo.
echo  [2/4] 지자체
python -m govpress collect-local --pages 2

echo.
echo  [3/4] 공공기관
python -m govpress collect-public --pages 2

echo.
echo  [4/4] 연구소
python -m govpress collect-research --pages 2

echo.
echo  화면을 엽니다...
python -m govpress dashboard --open

echo.
echo  ===================================================
echo    끝났습니다. 브라우저 창을 확인하세요.
echo    안 열렸으면 이 폴더의 dashboard.html 을 더블클릭.
echo  ===================================================
echo.
pause
exit /b 0

:NOPYTHON
echo  [!] 먼저 "1_처음에 한 번만.bat" 을 실행하세요.
echo.
pause
exit /b 1
