﻿@echo off
chcp 65001 > nul
cd /d "%~dp0"
title 보도자료 수집기 - 준비하기

echo.
echo  ===================================================
echo    보도자료 수집기 - 처음 한 번만 실행하세요
echo  ===================================================
echo.

where python >nul 2>nul
if errorlevel 1 goto NOPYTHON

echo  [1/2] 필요한 부품을 내려받는 중입니다...
echo.
python -m pip install --upgrade pip >nul 2>nul
python -m pip install -r requirements.txt
if errorlevel 1 goto FAILED

echo.
echo  [2/2] 확인 중...
python -m govpress depts >nul 2>nul
if errorlevel 1 goto FAILED

echo.
echo  ===================================================
echo    준비 끝났습니다.
echo    이제 "2_보도자료 모으기.bat" 을 더블클릭하세요.
echo  ===================================================
echo.
pause
exit /b 0

:NOPYTHON
echo  [!] 파이썬이 설치되어 있지 않습니다.
echo.
echo      1. https://www.python.org/downloads/  로 갑니다
echo      2. 노란 버튼(Download Python)을 누릅니다
echo      3. 내려받은 파일을 실행합니다
echo.
echo      *** 설치 첫 화면 맨 아래 ***
echo      *** "Add python.exe to PATH" 를 꼭 체크하세요 ***
echo      *** 이걸 빠뜨리면 여기서 또 막힙니다 ***
echo.
echo      4. 설치가 끝나면 이 파일을 다시 더블클릭하세요
echo.
pause
exit /b 1

:FAILED
echo.
echo  [!] 준비 중에 문제가 생겼습니다.
echo      위에 나온 영어 메시지를 그대로 찍어서 보내 주세요.
echo.
pause
exit /b 1
